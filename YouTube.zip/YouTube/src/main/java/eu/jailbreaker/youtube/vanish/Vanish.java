package eu.jailbreaker.youtube.vanish;

import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;

public class Vanish extends JavaPlugin implements Listener {

    private List<Player> vanish = new ArrayList<>();
    private String prefix = "§eVanish §8>> §7";

    @Override
    public void onEnable() {
        getServer().broadcastMessage(prefix + "§7wurde §a§laktiviert§8!");
        getCommand("vanish").setExecutor(new VanishCommand());
        getServer().getPluginManager().registerEvents(this, this);
    }

    @Override
    public void onDisable() {
        getServer().broadcastMessage(prefix + "§7wurde §c§ldeaktiviert§8!");
    }

    @EventHandler
    public void handleJoin(PlayerJoinEvent event) {
        Player p = event.getPlayer();

        if (!p.hasPermission("vanish.admin")) {
            vanish.forEach(p::hidePlayer);
        }
    }

    private class VanishCommand implements CommandExecutor {

        @Override
        public boolean onCommand(CommandSender sender, Command command, String s, String[] args) {
            assert sender instanceof ConsoleCommandSender;

            Player p = (Player) sender;

            /*
            /vanish
            /vanish <Spieler>
            /vanish list
             */

            if (!(p.hasPermission("vanish.use"))) {
                p.sendMessage(prefix + "§cDazu bist du nicht berechtigt§8!");
                return false;
            }

            if (args.length == 0) {
                if (vanish.contains(p)) {
                    undoVanish(p);
                } else {
                    doVanish(p);
                }
            } else if (args.length == 1) {

                if (!(p.hasPermission("vanish.admin"))) {
                    p.sendMessage(prefix + "§cDazu bist du nicht berechtigt§8!");
                    return false;
                }

                if (args[0].equalsIgnoreCase("list")) {
                    if (vanish.size() == 0) {
                        p.sendMessage(prefix + "§cNiemand ist gevanished");
                        return false;
                    }

                    StringBuilder sb = new StringBuilder("§e" + vanish.get(0).getName());
                    for (int i = 1; i < vanish.size(); i++) {
                        sb.append("§7, §e").append(vanish.get(i).getName());
                    }
                    p.sendMessage(prefix + "§7Folgende Spieler sind gevanished§8!");
                    p.sendMessage(prefix + sb.toString());
                    return false;
                }
                if (getServer().getPlayerExact(args[0]) == null) {
                    p.sendMessage(prefix + "§cDieser Spieler ist offline§8!");
                    return false;
                }
                Player t = getServer().getPlayerExact(args[0]);
                if (vanish.contains(t)) {
                    undoVanish(t);
                    p.sendMessage(prefix + t.getName() + " §7ist §cnicht mehr §7gevanished§8!");
                } else {
                    doVanish(t);
                    p.sendMessage(prefix + t.getName() + " §7ist §anun §7gevanished");
                }
            }

            return false;
        }

        private void doVanish(Player p) {
            vanish.add(p);
            p.playSound(p.getLocation(), Sound.BURP, 10, 1);
            getServer().getOnlinePlayers().stream().filter(player -> !player.hasPermission("vanish.admin")).forEach(player -> player.hidePlayer(p));
            p.sendMessage(prefix + "§7Du bist nun im Vanishmodus");

            p.setAllowFlight(true);
            p.setFlying(true);
        }

        private void undoVanish(Player p) {
            vanish.remove(p);
            p.playSound(p.getLocation(), Sound.BURP, 10, 1);

            getServer().getOnlinePlayers().forEach(player -> player.showPlayer(p));
            p.sendMessage(prefix + "§7Du bist nicht mehr im Vanishmodus");

            p.setAllowFlight(false);
            p.setFlying(false);
        }

        private void commandHelp(CommandSender sender) {
            sender.sendMessage(prefix + "§cFalsche Syntax§8: §7/vanish");
            sender.sendMessage(prefix + "§cFalsche Syntax§8: §7/vanish list");
            sender.sendMessage(prefix + "§cFalsche Syntax§8: §7/vanish <Spieler>");
        }
    }
}
