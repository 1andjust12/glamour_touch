package eu.jailbreaker.youtube.lottery;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Lists;
import com.google.common.collect.Multimap;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import lombok.Getter;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

public class LotteryPlugin extends JavaPlugin implements Listener {

    private File file;

    private Inventory startPage, finalPage;
    private List<Lottery> lotteries = Lists.newArrayList();

    private Random random = new Random();
    private Gson gson = new GsonBuilder().setPrettyPrinting().create();

    private Multimap<UUID, Integer> storage = ArrayListMultimap.create();
    private Map<UUID, Instant> cooldown = new HashMap<>();

    private String prefix = "§eLottery §8>> §7";

    @Override
    public void onEnable() {
        file = new File("plugins//" + getDescription().getName() + "//lotteries.json");

        startPage = getServer().createInventory(null, 9 * 6, "§5Lottery");
        finalPage = getServer().createInventory(null, 9 * 3, "§5Result");

        ItemStack paper = new ItemStack(Material.PAPER);
        for (int i = 0; i < startPage.getSize(); i++) {
            startPage.setItem(i, paper);
        }

        getCommand("lottery").setExecutor(new LotteryCommand());
        getServer().getPluginManager().registerEvents(this, this);
        load();
    }

    private class LotteryCommand implements CommandExecutor {

        @Override
        public boolean onCommand(CommandSender sender, Command command, String s, String[] args) {
            assert sender instanceof ConsoleCommandSender;

            Player p = (Player) sender;

            /*
            /lottery set - An der Position des Spieler soll lottery gespeichert werden
            /lottery list - Soll die Locations angeben
            /lottery remove <Id> - Soll eine LotteryPlugin Position entfernen
            /lottery teleport <Id>
             */

            if (args.length == 1) {
                if (args[0].equalsIgnoreCase("set")) {
                    int l = random.nextInt(5) + 6;
                    Lottery lottery = new Lottery(randomString(l), p.getLocation());
                    save(lottery);
                } else if (args[0].equalsIgnoreCase("list")) {
                    if (lotteries.size() == 0) {
                        p.sendMessage(prefix + "§cEs gibt keine Lotteries§8. §cXOXO");
                        return false;
                    }
                    StringBuilder sb = new StringBuilder("§7#§e" + lotteries.get(0).getId());
                    for (int i = 1; i < lotteries.size(); i++) {
                        sb.append("§7, §7#§e").append(lotteries.get(i).getId());
                    }
                    p.sendMessage(prefix + sb.toString());
                } else {
                    commandHelp(sender);
                }
            } else if (args.length == 2) {
                if (args[0].equalsIgnoreCase("remove")) {
                    String id = args[1];
                    delete(id);
                    p.sendMessage(prefix + "§7Du hast die Lottery mit der Id §e" + id + " §cgelöscht§8!");
                } else if (args[0].equalsIgnoreCase("teleport")) {
                    String id = args[1];

                    Optional<Lottery> optional = lotteries.stream().filter(lottery -> lottery.getId().equals(id)).findFirst();

                    if (!optional.isPresent()) {
                        p.sendMessage(prefix + "§cDiese Lottery gibt es nicht§8!");
                        return false;
                    }

                    p.teleport(optional.get().toLocation());
                    p.sendMessage(prefix + "§7Du wurdest zur Lottery mit der Id §e" + id + " §7teleportiert§8!");
                    p.playSound(p.getLocation(), Sound.BURP, 10, 1);
                } else {
                    commandHelp(sender);
                }
            } else {
                commandHelp(sender);
            }

            return false;
        }

        private void commandHelp(CommandSender sender) {
            sender.sendMessage(prefix + "§cHilfe§8: §7/lottery set");
            sender.sendMessage(prefix + "§cHilfe§8: §7/lottery list");
            sender.sendMessage(prefix + "§cHilfe§8: §7/lottery remove <Id>");
            sender.sendMessage(prefix + "§cHilfe§8: §7/lottery teleport <Id>");
        }
    }

    @EventHandler
    public void handlePlayerInteract(PlayerInteractEvent event) {
        Player p = event.getPlayer();
        if (event.getAction() == Action.RIGHT_CLICK_BLOCK) {
            if (event.getClickedBlock().getType() == Material.ENDER_CHEST) {
                if (lotteries.stream().anyMatch(lottery -> lottery.correct(event.getClickedBlock().getLocation()))) {
                    event.setCancelled(true);

                    if (cooldown.containsKey(p.getUniqueId()) && cooldown.get(p.getUniqueId()).isAfter(Instant.now())) {
                        p.sendMessage(prefix + "§cBitte habe etwas geduld");
                        return;
                    }
                    cooldown.remove(p.getUniqueId());

                    Inventory inv = cloneInventory(startPage);
                    storage.put(p.getUniqueId(), 0);
                    p.openInventory(inv);
                    p.playSound(p.getLocation(), Sound.LEVEL_UP, 10, 10);
                }
            }
        }
    }

    @EventHandler
    public void handleClick(InventoryClickEvent event) {
        Player p = (Player) event.getWhoClicked();

        if (event.getClickedInventory() == null) return;

        if (event.getClickedInventory().getTitle().equals(startPage.getTitle())) {
            event.setCancelled(true);

            if (event.getCurrentItem() == null) return;

            ItemStack item = event.getCurrentItem();
            ItemMeta meta = event.getCurrentItem().getItemMeta();

            if (item.getType() == Material.PAPER) {
                int coins = random.nextInt(1000);

                item.setType(Material.GOLD_NUGGET);
                meta.setDisplayName("§a" + coins);
                meta.addEnchant(Enchantment.LUCK, 1, true);

                storage.put(p.getUniqueId(), coins);

                event.getCurrentItem().setItemMeta(meta);
                p.playSound(p.getLocation(), Sound.LEVEL_UP, 10, 10);

                if (storage.get(p.getUniqueId()).size() >= 6) {
                    event.getView().close();

                    AtomicInteger ai = new AtomicInteger();
                    storage.get(p.getUniqueId()).forEach(ai::getAndAdd);

                    p.sendMessage(prefix + "§7Du hast §e" + ai.get() + " §7Coins §agewonnen§8!");
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE, 10, 10);

                    storage.removeAll(p.getUniqueId());
                    cooldown.put(p.getUniqueId(), Instant.now().plusSeconds(5));

                    // add coins to database
                }
            }
        }
    }

    private Inventory cloneInventory(Inventory inventory) {
        Inventory inv = getServer().createInventory(null, inventory.getSize(), inventory.getTitle());
        inv.setContents(inventory.getContents());
        return inv;
    }

    @Getter
    private class Lottery {
        private String id;
        private Map<String, Object> location;

        Lottery(String id, Location loc) {
            this.id = id;
            this.location = loc.serialize();
        }

        Location toLocation() {
            return Location.deserialize(location);
        }

        boolean correct(Object obj) {
            assert obj instanceof Location;
            Location l = toLocation();
            Location loc = (Location) obj;
            return l.getBlockX() == loc.getBlockX() && l.getBlockY() == loc.getBlockY() && l.getBlockZ() == loc.getBlockZ();
        }
    }

    public boolean lotteryExists(Lottery lottery) {
        return lotteries.stream().anyMatch(l -> (l.getId().equals(lottery.getId())));
    }

    private void save(Lottery lottery) {
        lotteries.add(lottery);
        updateFile();
    }

    private void delete(String id) {
        for (Lottery lottery : lotteries) {
            if (lottery.getId().equals(id)) {
                lotteries.remove(lottery);
            }
        }
        updateFile();
    }

    private void updateFile() {
        try (FileWriter fw = new FileWriter(file)) {
            fw.write(gson.toJson(lotteries));
            fw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void load() {
        try {
            if (!file.exists()) {
                Files.copy(Objects.requireNonNull(getClassLoader().getResourceAsStream("lotteries.json")), Paths.get(file.getPath()));
            }

            JsonArray array = gson.fromJson(new FileReader(file), JsonArray.class);
            array.forEach(jsonElement -> {
                Lottery lottery = gson.fromJson(jsonElement, Lottery.class);
                lotteries.add(lottery);
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String randomString(int count) {
        StringBuilder builder = new StringBuilder();
        while (count-- != 0) {
            String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";
            int character = (int) (Math.random() * alphabet.length());
            builder.append(alphabet.charAt(character));
        }
        return builder.toString();
    }
}
