package eu.jailbreaker.youtube.fly;

import org.bukkit.GameMode;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public class Fly extends JavaPlugin {

    private String prefix = "§eFly §8>> §7";

    @Override
    public void onEnable() {
        getServer().broadcastMessage(prefix + "§7wurde §a§laktiviert§8!");

        getCommand("fly").setExecutor(new FlyCommand());
    }

    @Override
    public void onDisable() {
        getServer().broadcastMessage(prefix + "§7wurde §c§ldeaktiviert§8!");
    }

    private class FlyCommand implements CommandExecutor {

        @Override
        public boolean onCommand(CommandSender sender, Command command, String s, String[] args) {
            assert sender instanceof ConsoleCommandSender;

            Player p = (Player) sender;

            /*
            /fly
            /fly <Spieler>
             */

            if (!sender.hasPermission("fly.use")) {
                p.sendMessage(prefix + "§cDazu bist du nicht berechtigt§8!");
                return false;
            }

            if (args.length == 0) {
                if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) {
                    p.sendMessage(prefix + "§cDu bist im falschen GameMode");
                    return false;
                }
                if (p.isFlying() || p.getAllowFlight()) {
                    setFlyStatus(p, false);
                    return false;
                }
                if (!p.isFlying() && !p.getAllowFlight()) {
                    setFlyStatus(p, true);
                }
            } else if (args.length == 1) {
                if (!sender.hasPermission("fly.admin")) {
                    p.sendMessage(prefix + "§cDazu bist du nicht berechtigt§8!");
                    return false;
                }
                if (getServer().getPlayerExact(args[0]) == null) {
                    p.sendMessage(prefix + "§cDieser Spieler ist offline§8!");
                    return false;
                }
                Player t = getServer().getPlayerExact(args[0]);

                if (t.getGameMode() == GameMode.CREATIVE || t.getGameMode() == GameMode.SPECTATOR) {
                    t.sendMessage(prefix + "§cDieser Spieler ist im falschen GameMode");
                    return false;
                }

                if (t.isFlying() || t.getAllowFlight()) {
                    setFlyStatus(t, false);
                    p.sendMessage(prefix + t.getName() + " §7kann nicht fliegen§8!");
                    return false;
                }
                if (!t.isFlying() && !t.getAllowFlight()) {
                    setFlyStatus(t, true);
                    p.sendMessage(prefix + t.getName() + " §7kann nun fliegen§8!");
                }
            }
            return false;
        }

        private void setFlyStatus(Player p, boolean status) {
            p.setAllowFlight(status);
            p.setFlying(status);
            if (status) {
                p.sendMessage(prefix + "§7Das Fliegen wird fortgesetzt§8! §cXOXO");
            } else {
                p.sendMessage(prefix + "§7Das Fliegen wurde unterbunden§8! §cXOXO");
            }
        }

        private void commandHelp(CommandSender sender) {
            sender.sendMessage(prefix + "§cFalsche Syntax§8: §7/fly");
            if (sender.hasPermission("fly.admin")) {
                sender.sendMessage(prefix + "§cFalsche Syntax§8: §7/fly <Spieler>");
            }
        }
    }
}
