package eu.jailbreaker.youtube.deathheight;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;
import java.util.Objects;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;

public class DeathHeight extends JavaPlugin {

    private Map<String, Height> heights = new ConcurrentHashMap<>();
    private File file;

    private Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private Random random = new Random();

    private String prefix = "§eDeathHeight §8>> §7";

    @Override
    public void onEnable() {
        getDataFolder().mkdir();
        file = new File("plugins//" + getDescription().getName() + "//heights.json");
        getServer().broadcastMessage(prefix + "§7wurde §a§laktiviert§8!");

        getServer().getPluginManager().registerEvents(new DeathHeightListener(), this);
        getCommand("sdh").setExecutor(new DeathHeightCommand());

        load();
    }

    @Override
    public void onDisable() {
        getServer().broadcastMessage(prefix + "§7wurde §c§ldeaktiviert§8!");
    }

    private class DeathHeightCommand implements CommandExecutor {

        @Override
        public boolean onCommand(CommandSender sender, Command command, String s, String[] args) {
            assert sender instanceof ConsoleCommandSender;

            Player p = (Player) sender;

            /*
            /sdh set
            /sdh set <Y>
            /sdh list
            /sdh remove <ID>
             */

            if (args.length == 1) {
                if (args[0].equalsIgnoreCase("set")) {
                    int l = random.nextInt(5) + 6;
                    Height h = new Height(randomString(l), round(p.getLocation().getY(), 4), p.getLocation().getWorld().getName());
                    save(h);
                    p.sendMessage(prefix + "§7Du hast die Todeshöhe der Karte §e" + h.getWorld() + " §7auf §6" + h.getY() + " §7gesetzt§8.");
                } else if (args[0].equalsIgnoreCase("list")) {
                    if (heights.size() == 0) {
                        p.sendMessage(prefix + "§cEs gibt keine Todeshöhen§8.");
                        return false;
                    }
                    StringBuilder sb = new StringBuilder();
                    for (Height height : heights.values()) {
                        sb.append(prefix)
                                .append("§7Welt§8:")
                                .append("§6")
                                .append(" ")
                                .append(height.getWorld())
                                .append(" ")
                                .append("§7Höhe§8: §6")
                                .append(height.getY())
                                .append(" §7#§e")
                                .append(height.getId())
                                .append("\n");
                    }
                    p.sendMessage(sb.toString());
                } else {
                    commandHelp(sender);
                }
            } else if (args.length == 2) {
                if (args[0].equalsIgnoreCase("set")) {
                    int l = random.nextInt(5) + 6;
                    Height h = new Height(randomString(l), Integer.parseInt(args[1]), p.getLocation().getWorld().getName());
                    save(h);
                    p.sendMessage(prefix + "§7Du hast die Todeshöhe der Karte §e" + h.getWorld() + " §7auf §6" + h.getY() + " §agesetzt§8.");
                } else if (args[0].equalsIgnoreCase("remove")) {
                    String id = args[1];
                    if (!idExists(id)) {
                        p.sendMessage(prefix + "§cDiese Id existiert nicht§8!");
                        return false;
                    }
                    Height h = getById(id);
                    delete(id);
                    p.sendMessage(prefix + "§7Du hast die Todeshöhe der Karte §e" + h.getWorld() + " §centfernt§8!");
                } else {
                    commandHelp(sender);
                }
            } else {
                commandHelp(sender);
            }
            return false;
        }

        private void commandHelp(CommandSender sender) {
            sender.sendMessage(prefix + "§cFalsche Syntax§8: §7/sdh set");
            sender.sendMessage(prefix + "§cFalsche Syntax§8: §7/sdh list");
            sender.sendMessage(prefix + "§cFalsche Syntax§8: §7/sdh set <Y>");
            sender.sendMessage(prefix + "§cFalsche Syntax§8: §7/sdh remove <Id>");
        }
    }

    private class DeathHeightListener implements Listener {
        @EventHandler
        public void handleMove(PlayerMoveEvent event) {
            Player p = event.getPlayer();
            Height h = heights.get(p.getWorld().getName());

            if (h != null) {
                h.kill(p);
            }
        }
    }

    @Getter
    @AllArgsConstructor
    private class Height {
        private String id;
        private double y;
        private String world;

        void kill(Player p) {
            if (p.getLocation().getY() <= this.y) {
                System.out.println("Killed");
                p.setHealth(0.0D);
            }
        }
    }

    private void save(Height h) {
        heights.put(h.getWorld(), h);
        this.updateFile();
    }

    private void delete(String id) {
        heights.values().stream().filter(height -> height.getId().equals(id)).forEach(height -> heights.remove(height.getWorld()));
        this.updateFile();
    }

    private boolean idExists(String id) {
        return heights.values().stream().anyMatch(height -> height.getId().equals(id));
    }

    private Height getById(String id) {
        return heights.values().stream().filter(height -> height.getId().equals(id)).findFirst().get();
    }

    private void updateFile() {
        try (FileWriter fw = new FileWriter(file)) {
            fw.write(gson.toJson(heights.values()));
            fw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void load() {
        try {
            if (!file.exists()) {
                Files.copy(Objects.requireNonNull(getClassLoader().getResourceAsStream("eu/jailbreaker/youtube/deathheight/heights.json")), Paths.get(file.getPath()));
            }

            JsonArray array = gson.fromJson(new FileReader(file), JsonArray.class);
            array.forEach(jsonElement -> {
                Height h = gson.fromJson(jsonElement, Height.class);
                heights.put(h.getWorld(), h);
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private double round(double value, int places) {
        if (places < 0) throw new IllegalArgumentException();

        BigDecimal bd = new BigDecimal(Double.toString(value));
        bd = bd.setScale(places, RoundingMode.HALF_UP);
        return bd.doubleValue();
    }

    private String randomString(int count) {
        StringBuilder builder = new StringBuilder();
        while (count-- != 0) {
            String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";
            int character = (int) (Math.random() * alphabet.length());
            builder.append(alphabet.charAt(character));
        }
        return builder.toString();
    }
}
